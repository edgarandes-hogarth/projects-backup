/* ========== UTILITIES ========== */

function getById(eleID) {
    return document.getElementById(eleID);
}

/* ========== CREATIVE ========== */

var splittedLines  = [];
var ctaActive      = "yes";
var nameLogoActive = "no";

var bannerData = {
    logo:          "logo.png",
    imgBackground: "bg-img.jpg",
    imgRibbon:      "ribbon.png",
    imgHeadline:    "healine.png",
    imgSubheadline: "subheadline.png",
    imgProduct:     "products.png",
    cta:            "cta.png"
};

var Creative = {

    onBannerStart: function() {
        console.log("Creative.onBannerStart()");
    },

    onBannerComplete: function() {
        console.log("Creative.onBannerComplete()");
    },

    startAd: function() {
        Creative.createButtons();
        Creative.displayBanner();
        Creative.populateData(bannerData);

        var adSizeMeta = document.querySelector('meta[name="ad.size"]');
        if (adSizeMeta) {
            var parts = adSizeMeta.content.split(",").map(function(size) {
                return size.replace(/(width=|height=)/, '').trim();
            });
            getById("main").style.setProperty('--ad-width', parts[0] + 'px');
            getById("main").style.setProperty('--ad-height', parts[1] + 'px');
        }

        Creative.init();
    },

    createButtons: function() {
    },

    displayBanner: function() {
        getById("main").style.display = "block";
        getById("loading_content").style.display = "none";
    },

    init: function() {
        Creative.setCreativeSettings();
        Creative.onBannerStart();

        // Reset state
        var splittedEls = document.querySelectorAll(".splitted-lines");
        splittedEls.forEach(function(el) {
            el.style.transform = "translateY(100%)";
            el.style.opacity = "0";
        });

        var fadeEls = document.querySelectorAll("#copyLocation");
        fadeEls.forEach(function(el) {
            el.style.opacity = "0";
        });

        Creative.onBannerComplete();
    }
};


/* ========== CREATIVE TOOLS ========== */

Creative.populateData = function(data) {
    for (var key in data) {
        var element = getById(key);
        if (element) {
            if (element.tagName === "IMG") {
                element.src = data[key];
            } else if (element.tagName === "SOURCE" && element.parentElement.tagName === "VIDEO") {
                element.src = data[key];
                element.load();
            } else {
                element.innerHTML = data[key];
            }
        }
    }
};

Creative.halfRetina = function(img) {
    var applySize = function() {
        img.style.width = (img.naturalWidth / 2) + "px";
        img.style.height = (img.naturalHeight / 2) + "px";
    };
    if (img.complete) applySize();
    img.onload = applySize;
};

Creative.setCreativeSettings = function() {
   
};

/* ========== Animation Loop ========== */


/* ========== BOOT ========== */
 Creative.startAd();
