// JS to set banners content to dynamic content loaded from DoubleClick

// create var to provide easy access to dynamic data
var _dynamicData = {};

//console.log("Hoxton ready!");
hoxton.timeline = Creative.tl;

// Define the function that should fire when the Ad Server is ready and assets are preloaded
hoxton.isInitialized = setDynamicContent;


/*
* Function sets any dynamic content
*/
function setDynamicContent() {
    //console.log("setDynamicContent()");

    // for shorthand references to state object
    _dynamicData = hoxton.getState();

    Creative.setExitURL(_dynamicData.exit_url);

    logoRedHeight = _dynamicData.logoRedHeight
    logoWhiteHeight = _dynamicData.logoWhiteHeight
    headline01FontSize = _dynamicData.headline01FontSize
    legalText01FontSize = _dynamicData.legalText01FontSize
    headline02FontSize = _dynamicData.headline02FontSize
    legalText02FontSize = _dynamicData.legalText02FontSize
    cta01 = _dynamicData.cta01
    ctaFontSize = _dynamicData.ctaFontSize
    partnerLogoDisplay = _dynamicData.partnerLogoDisplay
    mainSlide = _dynamicData.mainSlide
    bgSlideF2 = _dynamicData.bgSlideF2
    healthLogoDisplay = _dynamicData.healthLogoDisplay

    mainSlide = mainSlide.split(",").map(size => size.trim());

    getById("logoRed").style.height = logoRedHeight;
    getById("logoWhite").style.height = logoWhiteHeight;
    getById("headline01").style.fontSize = headline01FontSize;
    getById("legalText01").style.fontSize = legalText01FontSize;
    getById("headline02").style.fontSize = headline02FontSize;
    getById("legalText02").style.fontSize = legalText02FontSize;
    getById("cta01").style.fontSize = ctaFontSize;
    getById("cta02").style.fontSize = ctaFontSize;

    document.querySelector("#cta02").innerHTML = _dynamicData.cta01;
    showNonEmptyDivs("headline01", "headline02", "legalText01", "legalText02");

    /* checkFontsLoaded(['Mark Pro Black', 'Mark Pro Bold'],Creative.startAd)*/

    Creative.startAd();
}

function showNonEmptyDivs(...textIDs) {
  textIDs.forEach(id => {
    const el = document.getElementById(id);

    if (!el) return; // skip if element doesn't exist

    if (el.textContent.trim() !== "") {
      el.style.display = "block";
    } else {
      el.style.display = "none";
    }
  });
}