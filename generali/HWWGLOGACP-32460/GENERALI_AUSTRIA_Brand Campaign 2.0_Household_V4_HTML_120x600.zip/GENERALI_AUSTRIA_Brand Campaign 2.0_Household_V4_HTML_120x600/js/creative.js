
// looping config vars
var _totalLoops = 0;

let _currentLoop = 0;
const _maxLoops = 6;
var _endFrameDelay = 4;

// content
var container = getById("container");
var loadingContent = getById("loading_content");
// var logo3 = getById("logo3");

// exit
var exitBtn = getById("exit_btn");
var _exitURL = "https://www.generali.com/";
// const imagetl = gsap.timeline({ repeat:5});


//Dynamic Layout

var splittedLines = [];

// Create and provide timeline to Hoxton
var Creative = {

    tl: gsap.timeline({
        defaults: {
            ease: "none"
        },
        paused: true // important: let us control the play manually
    }),

    setExitURL: function (strURL) {
        _exitURL = strURL;
    },

    onExit: function (e) {
        hoxton.exit("Exit", _exitURL);
    },

    onBannerStart: function () {
        console.log("Creative.onBannerStart()");
    },

    onBannerComplete: function () {
        console.log("Creative.onBannerComplete()");
    },

    jumpToEndFrame: function () {
        Creative.tl.pause();
        Creative.tl.seek("end", false);
    },

    checkIsBackup: function () {
        return (window.location.href.indexOf('hoxtonBackup') >= 0) ? true : false;
    },

    startAd: function () {
        Creative.createButtons();
        Creative.displayBanner();


        Creative.setUpTimeline();

        Creative.init();
        Creative.checkIsBackup() ? Creative.jumpToEndFrame() : Creative.tl.play(0);
    },

    createButtons: function () {
        exitBtn.addEventListener("click", Creative.onExit, false);
    },

    setUpTimeline: function () {
        Creative.tl.repeat(_totalLoops);
        Creative.tl.repeatDelay(_endFrameDelay);
        Creative.tl.eventCallback("onStart", Creative.onBannerStart);
        Creative.tl.eventCallback("onComplete", Creative.onBannerComplete);
    },

    displayBanner: function () {
        loadingContent.style.display = "none";
        container.style.display = "block";
    },

    splitLines: function (copyId) {
        copyId.forEach((ids, index) => {
            const targetCopy = getById(ids);
            if (targetCopy && targetCopy.innerHTML.length > 0) {
                var splitText = new SplitText(targetCopy, { type: "lines", linesClass: "splitted-lines++ splitted-lines" });
                splittedLines[index] = splitText.lines;
            }
        })
    },


    init: function () {

        var redHeight = getById("redBG").offsetHeight;

        Creative.tl
            .add("reset")
            .set("#redBG", { y: redHeight }, "reset")
            .set(["#ctaContainer01", "#ctaContainer02", "#partnerLogo", "#logoRed"], { alpha: 0 }, "reset")
            .set("#logoWhite", { alpha: 0 }, "reset")
            .set(["#headline01", "#legalText01", "#headline02", "#legalText02"], { alpha: 0, x: -114 }, "reset")
            .set("#ctaContainer02", { y: 700 }, "reset")
            .set("#copyContainer02", { y: 600 }, "reset")

            .add("frame1", "+=0.2")
            .to("#logoRed", 0.5, { alpha: 1, ease: "power1.out" }, "frame1")
            .to("#redBG", 0.5, { y: 0, ease: "power1.out" }, "frame1+=0.5")
            .from("#healthLogo", 0.5, { alpha: 0, ease: "power1.out" }, ">")
            .to(["#headline01", "#legalText01"], 0.5, { alpha: 1, stagger: 0.25, x: 0, ease: "power1.out" }, "frame1+=1.2")
            .to("#partnerLogo", 0.5, { alpha: 1, ease: "power1.in" }, "frame1+=1.8")
            .to("#ctaContainer01", 0.5, { alpha: 1, ease: "power1.in" }, "frame1+=2")

            // frame1 Exit
            .to(["#headline01", "#legalText01", "#ctaContainer01", "#partnerLogo"], 0.5, { alpha: 0, ease: "power1.out" }, ">+=4")

            .add("frame2", "-=0.7")
            .to("#copyContainer02", 0.5, { y: 0, ease: "power1.out" }, "frame2+=0.4")
            .to("#redBG", 0.5, { alpha: 0, ease: "power1.out" }, "frame2+=0.8")
            .to("#logoWhite", 0.5, { alpha: 1, ease: "power1.out" }, "frame2+=1")
            .to("#ctaContainer02", 0.5, { alpha: 1, y: 0, ease: "power1.out" }, "frame2+=1")
            .to(["#headline02", "#legalText02"], 0.5, { alpha: 1, stagger: 0.25, x: 0, ease: "power1.out" }, "frame2+=2")

            // frame2 Exit
            .to(["#headline02", "#legalText02"], 0.5, { alpha: 0, ease: "power1.out" }, "frame2+=7.5")

            // frame3 In
            .add("frame3In", ">")
            .to("#logoWhite", 0.5, { alpha: 1, y: 170, ease: "power1.out" }, "frame3In")
            .to("#ctaContainer02", 0.5, { alpha: 1, y: 130, ease: "power1.out" }, "frame3In")


        // BACKGROUND SLIDE
        if (partnerLogoDisplay.toUpperCase() === "ON") {
            getById("partnerLogo").style.display = "block";
        } else if (partnerLogoDisplay.toUpperCase() === "OFF") {
            getById("partnerLogo").style.display = "none";
        }

        // PARTNER LOGO TOGGLE
        if (bgSlideF2.toUpperCase() === "ON") {
            Creative.tl
            .to("#mainBg", 0.5, { x: mainSlide[0], y: mainSlide[1], ease: "power1.out" }, "frame1+=0.5")
        } else if (bgSlideF2.toUpperCase() === "OFF") {
        }

        // HEALTH LOGO TOGGLE
        if (healthLogoDisplay.toUpperCase() === "ON") {
            getById("healthLogo").style.display = "block";
                const healthLogoHeight = getById('healthLogo').getBoundingClientRect().height;
                
                const div = document.getElementById('healthLogoContainer');
                const healthLogoPad = parseFloat( window.getComputedStyle(div).paddingBottom);     

                const totalHealth = healthLogoHeight + healthLogoPad + 5;
                
                document.getElementById('redBG').style.paddingBottom = `${totalHealth}px`;

                const divContainer02 = document.getElementById('copyContainer02');
                const container02_padding = parseFloat( window.getComputedStyle(divContainer02).paddingBottom);  

                const divlegalText02 = document.getElementById('legalText02');
                const legalText02_padding = parseFloat( window.getComputedStyle(divlegalText02).paddingBottom); 

                var newlegalText02 = totalHealth - container02_padding + legalText02_padding;
                document.getElementById('legalText02').style.paddingBottom = `${newlegalText02}px`;
        } else if (healthLogoDisplay.toUpperCase() === "OFF") {
            getById("healthLogo").style.display = "none";
        }

        Creative.tl
            .addLabel("end", ">")
    },

};


function getById(eleID) {
    return document.getElementById(eleID);
}
