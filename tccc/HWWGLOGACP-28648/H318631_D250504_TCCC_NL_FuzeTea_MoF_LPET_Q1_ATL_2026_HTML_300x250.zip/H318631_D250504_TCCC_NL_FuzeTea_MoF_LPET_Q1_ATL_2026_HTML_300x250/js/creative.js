
// looping config vars
var _totalLoops = 0;

let _currentLoop = 0;
const _maxLoops = 6;
var _endFrameDelay = 4;

// content
var container = getById("container");
var loadingContent = getById("loading_content");
// var logo3 = getById("logo3");

// exit
var exitBtn = getById("exit_btn");
var _exitURL = "https://www.proximus.com/";
// const imagetl = gsap.timeline({ repeat:5});


//Dynamic Layout

var splittedLines = [];

var mouseOverAnimationTriggered = false;
var over,
    out;

// Create and provide timeline to Hoxton
var Creative = {

    tl: gsap.timeline({
        defaults: {
            ease: "none"
        },
        paused: true // important: let us control the play manually
    }),

    over: gsap.timeline({
        defaults: {
            ease: "none",
            paused: false,
            force3D: true
        }
    }),

    out: gsap.timeline({
        defaults: {
            ease: "none",
            paused: false,
            force3D: true
        }
    }),

    setExitURL: function (strURL) {
        _exitURL = strURL;
    },

    onExit: function (e) {
        hoxton.exit("Exit", _exitURL);
    },

    onBannerStart: function () {
        container.classList.remove("cta-active");
    },
    onBannerComplete: function () {
        container.classList.add("cta-active");
    },

    jumpToEndFrame: function () {
        Creative.tl.pause();
        Creative.tl.seek("end", false);
        gsap.set("#cta", {
            backgroundColor: "#5c2d91",
            color: "#fff"
        });
    },

    checkIsBackup: function () {
        return (window.location.href.indexOf('hoxtonBackup') >= 0) ? true : false;
    },

    startAd: function () {
        Creative.createButtons();
        Creative.displayBanner();


        Creative.setUpTimeline();

        Creative.init();
        Creative.checkIsBackup() ? Creative.jumpToEndFrame() : Creative.tl.play(0);
    },

    createButtons: function () {
        exitBtn.addEventListener("click", Creative.onExit, false);
    },

    setUpTimeline: function () {
        Creative.tl.repeat(_totalLoops);
        Creative.tl.repeatDelay(_endFrameDelay);
        Creative.tl.eventCallback("onStart", Creative.onBannerStart);
        Creative.tl.eventCallback("onComplete", Creative.onBannerComplete);
    },

    displayBanner: function () {
        loadingContent.style.display = "none";
        container.style.display = "block";
    },

    splitLines: function (copyId) {
        copyId.forEach((ids, index) => {
            const targetCopy = getById(ids);
            if (targetCopy && targetCopy.innerHTML.length > 0) {
                var splitText = new SplitText(targetCopy, { type: "lines", linesClass: "splitted-lines++ splitted-lines" });
                splittedLines[index] = splitText.lines;
            }
        })
    },

    onMouseOver: function (e) {
        console.log("this is mouse over");
        mouseOverAnimationTriggered = true;
        Creative.over
            .to("#patchCont1", 0.5, { y: -1, scale: 1.1, ease: "back.out" }, 0)
            .to("#ctaFrame", .5, { border: "1px solid #fff", backgroundColor: "rgb(0, 0, 0, 0)", ease: Linear.easeNone }, 0)
            .to("#cta", .5, { color: "#fff", ease: Linear.easeNone }, 0)
            .restart();
    },

    onMouseLeave: function (e) {
        if (mouseOverAnimationTriggered) {
            mouseOverAnimationTriggered = true;
            Creative.out
                .to("#patchCont1", 0.5, { y: 0, scale: 1, ease: "back.inOut" }, 0)
                .to("#ctaFrame", .5, { backgroundColor: "#fff", ease: Linear.easeNone }, 0)
                .to("#cta", .5, { color: "#5c2d91", ease: Linear.easeNone }, 0)
                .restart();
            mouseOverAnimationTriggered = false;
        }
    },

    init: function () {
        Creative.tl
            .add("reset", "0")
            .set("#packshotShadow", {scaleX: 0.1, left: 15}, "reset")
            .set("#headerText, #cta",{alpha: 0}, "reset")

            .add("frame1", 0.5)
            .from("#logoFrame", {xPercent: -100, duration: 1}, "frame1")

            .add("frame2", 1.5)
            .from("#packshotFrame", {yPercent: 100, duration: 1, ease: "power2.out"}, "frame2")
            .from("#packshot1, #packshot2, #packshot4, #packshot5", {left: 120, duration: 0.5, ease: "power2.out"}, "frame2+=1")
            .to("#packshotShadow", {scaleX: 1, left:33, duration: 0.5, ease: "power2.out"}, "frame2+=1")

            .add("frame3", 3)
            .to("#headerText, #cta", {alpha: 1, duration: 1.5}, "frame3")
            
            .addLabel("end", ">")
    },

};



function getById(eleID) {
    return document.getElementById(eleID);
}
